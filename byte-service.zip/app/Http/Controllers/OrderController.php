<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Order;

class OrderController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return Order::all();
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $order = Order::create($request->all());

        $order->products()->attach($request->products);
    }

    private function format_show_response($order): Order
    {
        unset($order->id_payment_method);
        unset($order->id_client);

        $calculated_total = 0.0;
        $calculated_sale_total = 0.0;

        foreach($order->products as $product) {
            $calculated_total = $calculated_total + $product->pivot->quantity * $product->price;
            $calculated_sale_total = $calculated_sale_total + $product->pivot->quantity * $product->sale_price;
            $product->quantity = $product->pivot->quantity;
            unset($product->pivot);
        }

        $order->total = $calculated_total;
        $order->sale_total = $calculated_sale_total;

        return $order;
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $order = Order::with("client", "paymentMethod", "products")->findOrFail($id);

        return $this->format_show_response($order);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $order = Order::findOrFail($id);
        $order->update($request->all());
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $order = Order::findOrFail($id);
        $order->delete();
    }
}
